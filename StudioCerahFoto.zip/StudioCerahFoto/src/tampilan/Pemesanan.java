/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tampilan;

import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import koneksi.koneksi;

/**
 *
 * @author User
 */
public class Pemesanan extends javax.swing.JInternalFrame {
    private Connection conn = new koneksi().connect();
    private DefaultTableModel tabmode;
    private int selectedId = -1;

    private LinkedHashMap<String, Integer> mapCustomer = new LinkedHashMap<>();
    private LinkedHashMap<String, Integer> mapFotographer = new LinkedHashMap<>();
    private LinkedHashMap<String, Integer> mapPaket = new LinkedHashMap<>();

    /**
     * Creates new form Pemesanan
     */
    public Pemesanan() {
        initComponents();
        datatable();
        SelectCustomer();
        SelectFotographer();
        SelectPaket();
    }

    
    private void clearForm() {
        selectedId = -1;
        tabelCustomer.clearSelection();
        cbstatus.setSelectedIndex(0);
        if (cbcustomer.getItemCount() > 0) cbcustomer.setSelectedIndex(0);
        if (cbfotographer.getItemCount() > 0) cbfotographer.setSelectedIndex(0);
        if (cbpaket.getItemCount() > 0) cbpaket.setSelectedIndex(0);
    }
    
    
    public void datatable(){        
        DefaultTableCellRenderer headRender = new DefaultTableCellRenderer();
        headRender.setFont(new Font("Times New Roman", Font.BOLD, 14));
        headRender.setBackground(new Color(255,182,193));
        headRender.setForeground(Color.BLACK);
        headRender.setHorizontalAlignment(SwingConstants.CENTER);
        JTableHeader tableHeader = tabelCustomer.getTableHeader();
        tableHeader.setDefaultRenderer(headRender);
        Object[] Kolom = {"ID", "Nama Customer", "Fotographer", "Paket", "Tanggal", "Status"};
        tabmode = new DefaultTableModel(null, Kolom);
        tabelCustomer.setModel(tabmode);      
        String sql = "SELECT t.id, c.nama AS customer, f.nama AS fotografer, p.nama_paket AS paket, "
           + "t.tanggal_transaksi, t.status "
           + "FROM transaksi t "
           + "JOIN customer c ON t.id_customer = c.id "
           + "JOIN fotographer f ON t.id_fotographer = f.id "
           + "JOIN paket p ON t.id_paket = p.id "
           + "ORDER BY t.id DESC";
        try {
            Statement stat = conn.createStatement();
            ResultSet hasil = stat.executeQuery(sql);
            while(hasil.next()){
                String a = hasil.getString("id");
                String b = hasil.getString("customer");
                String d = hasil.getString("fotografer");
                String e = hasil.getString("paket");
                String f = hasil.getString("tanggal_transaksi");
                String g = hasil.getString("status");
                String[] data = {a, b, d, e, f, g};
                tabmode.addRow(data);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Gagal mengambil data: " + e.getMessage());
        }
    }
    
    private void SelectCustomer(){
        try {
            PreparedStatement pstCustomer = conn.prepareStatement("SELECT id, nama FROM customer ORDER BY id DESC");
            ResultSet rs1 = pstCustomer.executeQuery();
            cbcustomer.removeAllItems();
            mapCustomer.clear();       
            cbcustomer.addItem("PILIH");
            while (rs1.next()) {
                int id = rs1.getInt("id");
                String nama = rs1.getString("nama");
                mapCustomer.put(nama, id);  
                cbcustomer.addItem(nama);   
            }
            rs1.close();
            pstCustomer.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal load data combo: " + e.getMessage());
        }
    }
    
    private void SelectFotographer(){
        try {
            PreparedStatement pstFoto = conn.prepareStatement("SELECT id, nama FROM fotographer ORDER BY id DESC");
            ResultSet rs2 = pstFoto.executeQuery();
            cbfotographer.removeAllItems();
            mapFotographer.clear();
            cbfotographer.addItem("PILIH"); 
            while (rs2.next()) {
                int id = rs2.getInt("id");
                String nama = rs2.getString("nama");
                mapFotographer.put(nama, id);
                cbfotographer.addItem(nama);
            }
            rs2.close();
            pstFoto.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal load data combo: " + e.getMessage());
        }
    }
    
    private void SelectPaket(){
        try {
            PreparedStatement pstPaket = conn.prepareStatement("SELECT id, nama_paket FROM paket ORDER BY id DESC");
            ResultSet rs3 = pstPaket.executeQuery();
            cbpaket.removeAllItems();
            mapPaket.clear();
            cbpaket.addItem("PILIH"); 
            while (rs3.next()) {
                int id = rs3.getInt("id");
                String nama = rs3.getString("nama_paket");
                mapPaket.put(nama, id);
                cbpaket.addItem(nama);
            }
            rs3.close();
            pstPaket.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal load data combo: " + e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        clear = new javax.swing.JButton();
        save = new javax.swing.JButton();
        edit = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        cbfotographer = new javax.swing.JComboBox<>();
        cbpaket = new javax.swing.JComboBox<>();
        cbstatus = new javax.swing.JComboBox<>();
        cbcustomer = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelCustomer = new javax.swing.JTable();
        delete1 = new javax.swing.JButton();

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Pemesanan", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 24))); // NOI18N

        jPanel1.setBackground(new java.awt.Color(246, 244, 240));
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Customer");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Fotographer");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Paket");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Status");

        clear.setBackground(new java.awt.Color(176, 224, 230));
        clear.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        clear.setText("CLEAR");
        clear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearActionPerformed(evt);
            }
        });

        save.setBackground(new java.awt.Color(193, 255, 193));
        save.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        save.setText("SAVE");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        edit.setBackground(new java.awt.Color(255, 243, 176));
        edit.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        edit.setText("EDIT");
        edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editActionPerformed(evt);
            }
        });

        delete.setBackground(new java.awt.Color(255, 182, 193));
        delete.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        cbfotographer.setEditable(true);
        cbfotographer.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cbpaket.setEditable(true);
        cbpaket.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        cbstatus.setEditable(true);
        cbstatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cbstatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Booking", "Selesai" }));

        cbcustomer.setEditable(true);
        cbcustomer.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbstatus, 0, 200, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbpaket, 0, 200, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbfotographer, 0, 200, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(cbcustomer, 0, 200, Short.MAX_VALUE))
                    .addComponent(clear, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(edit, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cbcustomer, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbfotographer, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbpaket, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cbstatus, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addComponent(clear)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(save)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(edit)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(delete)
                .addContainerGap(75, Short.MAX_VALUE))
        );

        tabelCustomer.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tabelCustomer.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tabelCustomer.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelCustomerMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelCustomer);

        delete1.setBackground(new java.awt.Color(255, 255, 255));
        delete1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        delete1.setText("BACK");
        delete1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(delete1, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 22, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(delete1)
                .addContainerGap(21, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void clearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearActionPerformed
        // TODO add your handling code here:
        clearForm();
    }//GEN-LAST:event_clearActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        // TODO add your handling code here:
        //        String ID = id.getText().trim();
        try {
            int idCustomer = mapCustomer.getOrDefault((String) cbcustomer.getSelectedItem(), -1);
            int idFoto = mapFotographer.getOrDefault((String) cbfotographer.getSelectedItem(), -1);
            int idPaket = mapPaket.getOrDefault((String) cbpaket.getSelectedItem(), -1);
            String status = (String) cbstatus.getSelectedItem();
            Date tanggal = Date.valueOf(LocalDate.now());

            String sql = "INSERT INTO transaksi (id_customer, id_fotographer, id_paket, tanggal_transaksi, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, idCustomer);
            pst.setInt(2, idFoto);
            pst.setInt(3, idPaket);
            pst.setDate(4, tanggal);
            pst.setString(5, status);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Transaksi berhasil disimpan!");
            clearForm();
            datatable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal simpan: " + e.getMessage());
        }
    }//GEN-LAST:event_saveActionPerformed

    private void editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editActionPerformed
        // TODO add your handling code here:
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin diedit!");
            return;
        }

        try {
            int idCustomer = mapCustomer.getOrDefault((String) cbcustomer.getSelectedItem(), -1);
            int idFoto = mapFotographer.getOrDefault((String) cbfotographer.getSelectedItem(), -1);
            int idPaket = mapPaket.getOrDefault((String) cbpaket.getSelectedItem(), -1);
            String status = (String) cbstatus.getSelectedItem();

            String sql = "UPDATE transaksi SET id_customer=?, id_fotographer=?, id_paket=?, status=? WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setInt(1, idCustomer);
            pst.setInt(2, idFoto);
            pst.setInt(3, idPaket);
            pst.setString(4, status);
            pst.setInt(5, selectedId);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Data berhasil diperbarui!");
            clearForm();
            datatable();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal update: " + e.getMessage());
        }
    }//GEN-LAST:event_editActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
        if (selectedId == -1) {
            JOptionPane.showMessageDialog(this, "Pilih data yang ingin dihapus!");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data ini?", "Konfirmasi", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM transaksi WHERE id=?";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, selectedId);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(this, "Data berhasil dihapus!");
                clearForm();
                datatable();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal hapus: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void tabelCustomerMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelCustomerMouseClicked
        // TODO add your handling code here:
        int row = tabelCustomer.getSelectedRow();
        if (row != -1) {
            selectedId = Integer.parseInt(tabmode.getValueAt(row, 0).toString());
            cbcustomer.setSelectedItem(tabmode.getValueAt(row, 1).toString());
            cbfotographer.setSelectedItem(tabmode.getValueAt(row, 2).toString());
            cbpaket.setSelectedItem(tabmode.getValueAt(row, 3).toString());
            cbstatus.setSelectedItem(tabmode.getValueAt(row, 5).toString());
        }
    }//GEN-LAST:event_tabelCustomerMouseClicked

    private void delete1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete1ActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_delete1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cbcustomer;
    private javax.swing.JComboBox<String> cbfotographer;
    private javax.swing.JComboBox<String> cbpaket;
    private javax.swing.JComboBox<String> cbstatus;
    private javax.swing.JButton clear;
    private javax.swing.JButton delete;
    private javax.swing.JButton delete1;
    private javax.swing.JButton edit;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton save;
    private javax.swing.JTable tabelCustomer;
    // End of variables declaration//GEN-END:variables
}
